<?php
namespace App\Models\ORM;

use App\Models\AutentificadorJWT;
use App\Models\ORM\Usuario;
use App\Models\ORM\Mensaje;
use App\Models\ORM\Ingreso;
use App\Models\ORM\Egreso;
use App\Models\IApiControler;

include_once __DIR__ . '/usuario.php';
include_once __DIR__ . '/mensaje.php';
include_once __DIR__ . '../../modelAPI/IApiControler.php';
include_once __DIR__ . '../../modelAPI/AutentificadorJWT.php';


use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;


class UsuarioController implements IApiControler 
{
 	public function Beinvenida($request, $response, $args) {
      $response->getBody()->write("GET => Bienvenido!!! ,a UTN FRA SlimFramework");
    
    return $response;
    }

    public function TraerTodos($request, $response, $args) {
        //return cd::all()->toJson();
        //addLog($request->getMethod(), $request->getUri()->getPath());
        $todosLosUsuarios=usuario::all();
        $newResponse = $response->withJson($todosLosUsuarios, 200);  
        return $newResponse;
    }
    public function TraerUno($request, $response, $args) {
        $id = $args['id'];
        $usuario = usuario::find($id);
        $newResponse = $response->withJson($usuario, 200);  
        return $newResponse;
    }
   
    public function CargarUno($request, $response, $args) {
        //addLog($request->getMethod(), $request->getUri()->getPath());
        $arry_params = $request->getParsedBody();
        $arrayFotos = $request->getUploadedFiles();
        if(array_key_exists("email", $arry_params) && array_key_exists("clave", $arry_params)
        && array_key_exists("tipo", $arry_params) && array_key_exists("foto1", $arrayFotos)
        && array_key_exists("foto2", $arrayFotos)&& !usuario::where('email', '=', $arry_params["email"])->exists())
        {
            
            $usuario= new usuario;
            $usuario->email = $arry_params['email'];
            $usuario->clave = crypt($arry_params['clave'],'st');
            $usuario->tipo = $arry_params['tipo'];
            $arrayFotos = $request->getUploadedFiles();
            
            //foto1
            $extension = $arrayFotos['foto1']->getClientFilename();
            $extension = explode(".", $extension);
            $filenameUno = "./images/users/" . $usuario->email . "1." . $extension[1];
            $arrayFotos["foto1"]->moveTo($filenameUno);
            $usuario->foto1 =  $filenameUno;

            //Foto2
            $extension = $arrayFotos["foto2"]->getClientFilename();
            $extension = explode(".", $extension);
            $filenameDos = "./images/users/" . $usuario->email . "2." . $extension[1];
            $arrayFotos["foto2"]->moveTo($filenameDos);
            $usuario->foto2 =  $filenameDos;
            
            $usuario->save();
            $newResponse = $response->withJson($usuario, 200);  
        
        }
        else {
            $newResponse = $response->withJson("Faltan datos o el usuario ya existe, vuelva a intentarlo", 200);
        }
        return $newResponse;
        
    }

      public function BorrarUno($request, $response, $args) {
  		//complete el codigo
     	$newResponse = $response->withJson("sin completar", 200);  
      	return $newResponse;
    }
     
     public function ModificarUno($request, $response, $args) {
       
    }

    public function Login($request,$response,$args){
      $datos = $request->getParsedBody();
      $clave = $datos['clave'];
      $email = $datos['email'];
      $usuario = Usuario::where('email','=',$datos['email'])
        ->select('id','email','clave','tipo','foto1','foto2')
        ->get()
        ->toArray();
      $emailValido = strcasecmp($usuario[0]["email"],$email);
      $claveValida = strcasecmp($usuario[0]["clave"],crypt($clave,'st'));
      if (count($usuario) == 1 && $claveValida == 0 && $emailValido == 0) {
        unset($usuario[0]['clave']);
        $token = AutentificadorJWT::CrearToken($usuario[0]);
        $newResponse = $response->withJson($token, 200);
        //$newResponse = "Logueo correcto. Su token es: " . $response->withJson($token, 200);
      }
      else {
        $newResponse = $response->withJson("No se pudo iniciar sesion, error al generar el token, vuelva a intentarlo", 200);
      }
      return $newResponse;
    }

   
    public function IngresarMensaje($request,$response,$args){
      $token = $request->getHeader("token")[0];
      $data = AutentificadorJWT::ObtenerData($token);
      $datos = $request->getParsedBody();
      $mensaje = new Mensaje;
      $mensaje->mensaje = $datos['mensaje'];
      $mensaje->id_usuario_destino = $datos['id_usuario_destino'];
      $mensaje->id_usuario_emisor = $data->id;

      if(usuario::where('email', '=', $data->email)->exists()){
        $mensaje->save();
        $newResponse = $response->withJson("Mensaje enviado", 200);
      }
      return $newResponse;
    }

    public function GetMensaje($request,$response,$args){
      $token = $request->getHeader("token")[0];
      $data = AutentificadorJWT::ObtenerData($token);
      $tipo = $data->tipo;
      if($tipo == "user")
      {
        $datos_mensajes = Mensaje::where("id_usuario_emisor","=",$data->id)->select("id_usuario_destino","mensaje","created_at")->get()->toArray();
        $datos_mensajes_aux = Array();
        foreach ($datos_mensajes as $value){
          $email_mensajes = Usuario::where('id','=',$value['id_usuario_destino'])->select("email")->get()[0];
          $value['email'] = $email_mensajes->email;
          $datos_mensajes_aux[] = $value;
        }
        $newResponse = $response->withJson($datos_mensajes_aux,200);
      }
      elseif($tipo == "admin"){
        //$datos_mensajes = Mensaje::where("id_usuario_emisor","=","id_usuario_destino")->select("id","mensaje","created_at")->get()->toArray();
        //$newResponse = $response->withJson($datos_mensajes,200);
      }
      return $newResponse;
    }

    public function MensajesEnviados($request,$response,$args){
      $token = $request->getHeader("token")[0];
      $data = AutentificadorJWT::ObtenerData($token);
      $tipo = $data->tipo;
      if(!$tipo == "admin")
      {
        $user_info = Mensaje::groupBy('id_usuario_emisor')->select('id_usuario_emisor', DB::raw('count(*) as total'))->get();
        $newResponse =  $response->withJson($user_info, 200);
      }else{
        $newResponse = $response->withJson("Acceso denegado. Solo administradores", 200);
      }
      return $newResponse;
    }

}